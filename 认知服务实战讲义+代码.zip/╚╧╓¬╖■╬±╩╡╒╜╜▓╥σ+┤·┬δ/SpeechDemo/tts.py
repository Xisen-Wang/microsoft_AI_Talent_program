import azure.cognitiveservices.speech as speechsdk

speech_key, service_region = "28198fb347e3451aabca72831fec42bb", "chinaeast2"
language = 'zh-CN'


def tts_mic():
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_config.speech_synthesis_language = language
    voice = "Microsoft Server Speech Text to Speech Voice (zh-CN, XiaoyouNeural)"
    speech_config.speech_synthesis_voice_name = voice
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)

    while True:
        print("请输入期望转换的text ctl+z 退出")
        try:
            txt = input()
        except EOFError as e:
            #print(e)
            break
        result = speech_synthesizer.speak_text_async(txt).get()
        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            print("识别结果:[{}]".format(txt))
        if result.reason == speechsdk.ResultReason.Canceled:
            cancellation_details = result.cancellation_details
            print("识别取消: {}".format(cancellation_details.reason))
            if cancellation_details.reason == speechsdk.CancellationReason.Error:
                print("错误: {}".format(cancellation_details.error_details))


def tts_file(txt):
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_config.speech_synthesis_language = language
    voice = "Microsoft Server Speech Text to Speech Voice (zh-CN, XiaoyouNeural)"
    speech_config.speech_synthesis_voice_name = voice

    audio_config = speechsdk.audio.AudioConfig(filename="output.wav")
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    result = speech_synthesizer.speak_text_async(txt).get()
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("识别结果:[{}]".format(txt))
    if result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        print("识别取消: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            print("错误: {}".format(cancellation_details.error_details))

def tts_ssml():
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_config.speech_synthesis_language = language
    voice = "Microsoft Server Speech Text to Speech Voice (zh-CN, XiaoyouNeural)"
    speech_config.speech_synthesis_voice_name = voice

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)

    txt = "<speak version=\"1.0\" xmlns=\"http://www.w3.org/2001/10/synthesis\" xml:lang=\"zh-CN\">"
    txt += " <voice name=\"zh-CN-XiaomoNeural\">"
    txt += "   你好，欢迎是用微软认知服务"
    txt += " </voice>"
    txt += " <voice name=\"zh-CN-YunxiNeural\">"
    txt += "   你好，欢迎是用微软认知服务"
    txt += " </voice>"
    txt += "</speak>"
    result = speech_synthesizer.speak_ssml_async(txt).get()

    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("识别结果:[{}]".format(txt))
    if result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        print("识别取消: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            print("错误: {}".format(cancellation_details.error_details))

# tts_mic()
# tts_file("欢迎您使用微软认知服务")
tts_ssml()