import azure.cognitiveservices.speech as speechsdk
speech_key, service_region = "28198fb347e3451aabca72831fec42bb", "chinaeast2"
language = 'zh-CN'

def stt_from_mic():
    speech_config=speechsdk.SpeechConfig(subscription=speech_key,region=service_region)
    speech_config.speech_recognition_language=language
    speech_recognizer=speechsdk.SpeechRecognizer(speech_config=speech_config)
    result =speech_recognizer.recognize_once()

    if  result.reason == speechsdk.ResultReason.RecognizedSpeech:
        print("识别内容[{}]".format(result.text))
    elif result.reason == speechsdk.ResultReason.NoMatch:
        print("No speech could be recognized")
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        print("Speech Recognition canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            print("Error details: {}".format(cancellation_details.error_details))

def stt_from_file():
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_config.speech_recognition_language = language
    audio_config=speechsdk.audio.AudioConfig(filename="output.wav")

    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config,audio_config=audio_config)
    result = speech_recognizer.recognize_once()

    if  result.reason == speechsdk.ResultReason.RecognizedSpeech:
        print("识别内容[{}]".format(result.text))
    elif result.reason == speechsdk.ResultReason.NoMatch:
        print("No speech could be recognized")
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        print("Speech Recognition canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            print("Error details: {}".format(cancellation_details.error_details))


# stt_from_mic()
stt_from_file()
